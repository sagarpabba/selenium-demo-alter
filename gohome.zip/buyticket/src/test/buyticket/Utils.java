package test.buyticket;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.apache.http.message.BasicHeader;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class Utils {
	
	private static final Map<String,String> seatTypeAndNames = new HashMap<String,String>(){
		private static final long serialVersionUID = 1L;
		{		
			put("硬座", "1,13");//1是座位类型号，13是在查询结果数组中的索引
			put("软座", "2,12");
			put("硬卧", "3,11");
			put("软卧", "4,10");
			put("高级软卧", "6,9");
			put("二等座","O,8");
			put("一等座", "M,7");
			put("特等座", "P,6");
			put("商务座","9,5");
		}
	};
	public static String getPassengerTickets(Map<String, String> orderData) {
		StringBuilder sb = new StringBuilder();
		sb.append(orderData.get("passenger_1_seat")).append(",");
		sb.append(orderData.get("passenger_1_seat_detail")).append(",");
		sb.append(orderData.get("passenger_1_ticket")).append(",");
		sb.append(orderData.get("passenger_1_name")).append(",");
		sb.append(orderData.get("passenger_1_cardtype")).append(",");
		sb.append(orderData.get("passenger_1_cardno")).append(",");
		sb.append(orderData.get("passenger_1_mobileno")).append(",");
		sb.append("Y");
		return sb.toString();
	}
	public static String[] matchTicket(String[] queryResultArr,String expectedSeatTypes){
		/*
		String trainCode  = queryResultArr[1];
		String fromStation = queryResultArr[2];//&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;北京西&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp;&nbsp;22:30,
		String toStation = queryResultArr[3];
		String usetime = queryResultArr[4];
		String shangWuZuo = queryResultArr[5];
		String teDengZuo = queryResultArr[6];
		String yiDengZuo = queryResultArr[7];
		String erDengZuo = queryResultArr[8];
		String gaoJiRuanWo = queryResultArr[9];
		String ruanWo = queryResultArr[10];
		String yingWo = queryResultArr[11];
		String ruanZuo = queryResultArr[12];
		String yingZuo = queryResultArr[13];
		String wuZuo = queryResultArr[14];
		*/
		String[] expectedSeatTypeArr = expectedSeatTypes.split(",");
		for(int i=0;i<expectedSeatTypeArr.length;i++){
			String expectedSeat = expectedSeatTypeArr[i];
			int seatIndex = getSeatIndex(expectedSeat);
			String queryResult = queryResultArr[seatIndex];
			if( !queryResult.equals("-")&& !queryResult.equals("无")){
				String input = queryResultArr[16];
				String seatInfo = input.replaceAll(".*\\('(.*)'\\).*","$1");
				String seatInfoArr[] = seatInfo.split("#");
				if(seatInfoArr != null && seatInfoArr.length >= 10){
					return seatInfoArr;
				}
			}
		}
		return null;
	}
	public static List<String> getExpectedSeatAvailable(String seatAvailable,String expectedSeatTypes){
		if(seatAvailable == null || seatAvailable.length() <=0 ){
			return null;
		}
		
		String[] seatAvailableArr = seatAvailable.split(",");
		String[] seatExpectedArr =  expectedSeatTypes.split(",");
		List<String> retlist = new ArrayList<String>(seatAvailableArr.length);
		for(String seatExpected : seatExpectedArr){
			for(String seat : seatAvailableArr){
				if(seatExpected.equals(seat)){
					retlist.add(seat);
				}
			}
		}
		return retlist;
	}
	public static String getSeatNo(String seatType){
		String str = seatTypeAndNames.get(seatType);
		return str.split(",")[0];
	}
	public static int getSeatIndex(String seatType){
		String str = seatTypeAndNames.get(seatType);
		return Integer.valueOf(str.split(",")[1]);
	}
	public static Header[] buildHeader(Header referHeader,Header[] cookieHeaders){
		Header[] headers = new Header[1+cookieHeaders.length];
		headers[0] = referHeader;
		for(int i=0;i<cookieHeaders.length;i++){
			headers[i+1] = cookieHeaders[i];
		}
		return headers;
	}
	public static Header makeReferHeader(String refer){
		Header referHeader = new BasicHeader("Referer",refer);
		return referHeader;
	}
	public static String getStrutsToken(String content){
		if(content == null || content.equals("")){
			return "";
		}
		Matcher m = Pattern.compile("(?is)<input .*?name=\"org.apache.struts.taglib.html.TOKEN\".*?value=\"(\\w+)\".*/?>").matcher(content);
		if(m.find()){
			System.out.println("Find the struts2 token is:"+m.group(1));
			return m.group(1);
		}
		return "";
	}
	public static String getLeftTicketToken(String content){
		if(content == null || content.equals("")){
			return "";
		}
		Matcher m = Pattern.compile("(?is)<input.*?id=\"left_ticket\".*?value=\"(\\w+)\".*/?>").matcher(content);
		if(m.find()){
			System.out.println("get the left ticket token is:"+m.group(1));
			return m.group(1);
		}
		return "";
	}
	public static String getSeatAvailable(String content){
		if(content == null || content.equals("")){
			return "";
		}
		StringBuilder sb = new StringBuilder();
		Matcher m = Pattern.compile("(?is)<select.*?id=\"passenger_1_seat\".*?</select>").matcher(content);
		if(m.find()){
			String select = m.group();
			//System.out.println("seat avaliable:"+select);
			m = Pattern.compile("(?is)<option.*?>(.*?)</option>").matcher(select);
			while(m.find()){
				sb.append(m.group(1)).append(",");
			}
			if(sb.length() > 0){
				sb.deleteCharAt(sb.length()-1);
			}
		}
		return sb.toString();
	}
	public static String getContent(InputStream is)throws Exception{
		StringBuilder sb = new StringBuilder();
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String line = "";
		while ((line = br.readLine()) != null) {
			sb.append(line);
			sb.append("\n");
		}
		close(is,br);
		return sb.toString();
	}
	public static byte[] readInputStream(InputStream in)throws Exception{
		byte[] buff = new byte[1024];
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		int len = 0;
		while((len = in.read(buff))>-1){
			bo.write(buff,0,len);
		}
		close(bo,in);
		return bo.toByteArray();
	}
	public static boolean saveInputStreamAsPic(InputStream in)throws Exception{
		FileOutputStream out = new FileOutputStream("C:\\passCodeAction.jpg");
		byte[] buff = new byte[1024];
		int len = 0;
		while((len = in.read(buff)) > -1){
			//System.out.println("图片大小："+len);
			out.write(buff,0,len);
		}
		close(in,out);
		return true;
	}
	public static String inputRandCodeFromConsole()throws Exception{
		InputStream in = System.in;
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line = br.readLine();
		return line;
	}
	public static void close(Closeable... closeables){
		if(closeables != null){
			for(Closeable closeable : closeables){
				try{
					closeable.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	}
	public static void loadParamBeanFromConf(ParamBean pb,String conf){
		try{
			File f = new File(conf);
			if(!f.exists()){
				initBean(pb);
				return;
			}
			Map<String,String> config = readProperties(conf);
			pb.setUsername(config.get("username"));
			pb.setPassword(config.get("password"));
			pb.setExpectedSeatTypes(config.get("expectedSeatTypes"));
			pb.setFromStationName(config.get("fromStationName"));
			pb.setIdcard(config.get("idcard"));
			pb.setName(config.get("name"));
			pb.setTel(config.get("tel"));
			pb.setToStationName(config.get("toStationName"));
			pb.setTrainCode(config.get("trainCode"));
			pb.setTicketDate(config.get("ticketDate"));
		}catch(Exception e){
			//do noting
		}
	}
	public static Map<String,String> readProperties(String conf)throws Exception{
		InputStream in = new FileInputStream(conf);
		BufferedReader br = new BufferedReader(new InputStreamReader(in,"GB2312"));
		String line = "";
		Map<String,String> config = new HashMap<String,String>();
		while((line = br.readLine()) != null){
			if(line.startsWith("#")){
				continue;
			}
			String key = line.split("=")[0];
			String value = line.split("=")[1];
			if(value == null || value.trim().equals("")){
				value = "";
			}
			config.put(key.trim(), value);
		}
		close(in,br);
		return config;
	}
	public static void initBean(ParamBean pb){
		try{
			Field[] fields = pb.getClass().getDeclaredFields();
			for(Field field : fields){
				field.setAccessible(true);
				if(field.getType() == String.class){
					field.set(pb, "");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
