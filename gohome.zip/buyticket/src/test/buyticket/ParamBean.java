package test.buyticket;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class ParamBean {
	/**登陆系统的账号和密码*/
	private String username;
	private String password;
	/**真实姓名，身份证号，手机号*/
	private String name;
	private String idcard ;
	private String tel;
	/**要预定的车票的信息*/
	private String fromStationName;
	private String toStationName;
	private String trainCode;
	private String trainNo;
	private String ticketDate;
	private String expectedSeatTypes;//可以填多个，用逗号分开
	private String orderRandcode;//订单验证码

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getFromStationName() {
		return fromStationName;
	}
	public void setFromStationName(String fromStationName) {
		this.fromStationName = fromStationName;
	}
	public String getToStationName() {
		return toStationName;
	}
	public void setToStationName(String toStationName) {
		this.toStationName = toStationName;
	}
	public String getTrainCode() {
		return trainCode;
	}
	public void setTrainCode(String trainCode) {
		this.trainCode = trainCode;
	}
	public String getTrainNo() {
		return trainNo;
	}
	public void setTrainNo(String trainNo) {
		this.trainNo = trainNo;
	}
	public String getTicketDate() {
		return ticketDate;
	}
	public void setTicketDate(String ticketDate) {
		this.ticketDate = ticketDate;
	}
	public String getExpectedSeatTypes() {
		return expectedSeatTypes;
	}
	public void setExpectedSeatTypes(String expectedSeatTypes) {
		this.expectedSeatTypes = expectedSeatTypes;
	}
	public String getOrderRandcode() {
		return orderRandcode;
	}
	public void setOrderRandcode(String orderRandcode) {
		this.orderRandcode = orderRandcode;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
