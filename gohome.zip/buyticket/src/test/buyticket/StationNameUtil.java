package test.buyticket;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class StationNameUtil {
	private static Map<String,String> stationMap = getStationMap();
	
	public static Map<String,String> getStationMap(){
		try{
			InputStream in = Main.class.getResourceAsStream("stationNames.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String line = br.readLine();
			String[] stations = line.split("@");
			Map<String,String> stationMap = new HashMap<String,String>();
			for(int i=0;i<stations.length;i++){
				String station = stations[i];
				String stationZhName = station.split("\\|")[1];
				stationMap.put(stationZhName,station);
			}
			return stationMap;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	public static String getStationByZhName(String zhName){
		if(stationMap == null || stationMap.size() <= 0){
			stationMap = getStationMap();
		}
		return stationMap.get(zhName);
	}
	public static String getStationTelecode(String zhName){
		if(stationMap == null || stationMap.size() <= 0){
			stationMap = getStationMap();
		}
		String station = stationMap.get(zhName);
		if(station == null){
			throw new RuntimeException("你确定"+zhName+"是中国的火车站？");
		}
		return station.split("\\|")[2];
	}
	
	public static void main(String[] args) throws Exception {
	/*	Map<String,String> stationMap = getStationMap();
		for(Map.Entry<String,String> station : stationMap.entrySet()){
			System.out.println(station.getKey()+","+station.getValue());
		}*/
		System.out.println("----------");
		System.out.println(getStationByZhName("上海"));
	}
}
