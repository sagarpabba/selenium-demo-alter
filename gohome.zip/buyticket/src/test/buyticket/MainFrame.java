package test.buyticket;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

import org.apache.http.Header;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class MainFrame extends JFrame{
	private static final long serialVersionUID = 1L;
	
	private static JLabel     l_username;
	private static JTextField t_username;
	
	private static JLabel     l_password;
	private static JTextField t_password;
	
	private static JLabel     l_randcode;
	private static JTextField t_randcode;
	private static JButton    btn_randcode;
	
	private static JButton    btn_login;
	
	private static JLabel     l_user;
	private static JTextField t_user;
	private static JLabel     l_idcard;
	private static JTextField t_idcard;
	private static JLabel     l_tel;
	private static JTextField t_tel;
	private static JLabel     l_fromStationName;
	private static JTextField t_fromStationName;
	private static JLabel     l_toStationName;
	private static JTextField t_toStationName;
	private static JLabel     l_trainCode;
	private static JTextField t_trainCode;
	private static JLabel     l_ticketDate;
	private static JTextField t_ticketDate;
	private static JLabel     l_expectedSeatTypes;
	private static JTextField t_expectedSeatTypes;
	
	private static JTextArea  ta_log;
	private static JScrollPane p_log;
	
	private static MainFrame frame;

	private static Header[] httpsCookieHeaders;
	
	private static ParamBean pb = new ParamBean();
	
	static{
		Utils.loadParamBeanFromConf(pb,"d:/狗日的铁道部/conf.txt");
	}
	
	public MainFrame(){
		super("自动购票");
		l_username = new JLabel("用户名",SwingConstants.LEFT);
		t_username = new JTextField(pb.getUsername(),20);
		JPanel p_username = new JPanel();
		p_username.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_username.add(l_username);
		p_username.add(t_username);
		
		l_password = new JLabel("密    码",SwingConstants.LEFT);
		t_password = new JTextField(pb.getPassword(),20);
		JPanel p_password = new JPanel();
		p_password.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_password.add(l_password);
		p_password.add(t_password);
		
		l_randcode = new JLabel("验证码",SwingConstants.LEFT);
		t_randcode = new JTextField(20);
		l_randcode.setDisplayedMnemonic('r');
		l_randcode.setLabelFor(t_randcode);
		btn_randcode =  new JButton();
		btn_randcode.setMargin(null);
		btn_randcode.setBorder(null);
		btn_randcode.addActionListener(new GetRandCodeListener());
		JPanel p_randcode = new JPanel();
		p_randcode.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_randcode.add(l_randcode);
		p_randcode.add(t_randcode);
		p_randcode.add(btn_randcode);
		
		JPanel p_website = new JPanel();
		TitledBorder border =new TitledBorder("login information"); 
		p_website.setBorder(border);
		p_website.setLayout(new GridLayout(3,1));
		p_website.add(p_username);
		p_website.add(p_password);
		p_website.add(p_randcode);
		
		l_user = new JLabel("姓    名",SwingConstants.LEFT);
		t_user = new JTextField(pb.getName(),20);
		JPanel p_user = new JPanel();
		p_user.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_user.add(l_user);
		p_user.add(t_user);
		
		l_idcard = new JLabel("身份证",SwingConstants.LEFT);
		t_idcard = new JTextField(pb.getIdcard(),20);
		JPanel p_idcard= new JPanel();
		p_idcard.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_idcard.add(l_idcard);
		p_idcard.add(t_idcard);
		
		l_tel = new JLabel("手机号",SwingConstants.LEFT);
		t_tel = new JTextField(pb.getTel(),20);
		JPanel p_tel= new JPanel();
		p_tel.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_tel.add(l_tel);
		p_tel.add(t_tel);
		
		l_fromStationName = new JLabel("始发站",SwingConstants.LEFT);
		t_fromStationName = new JTextField(pb.getFromStationName(),10);
		l_toStationName = new JLabel("终点站",SwingConstants.LEFT);
		t_toStationName = new JTextField(pb.getToStationName(),10);
		l_trainCode = new JLabel("车次",SwingConstants.LEFT);
		t_trainCode = new JTextField(pb.getTrainCode(),10);
		JPanel p_train= new JPanel();
		p_train.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_train.add(l_fromStationName);
		p_train.add(t_fromStationName);
		p_train.add(l_toStationName);
		p_train.add(t_toStationName);
		p_train.add(l_trainCode);
		p_train.add(t_trainCode);
		
		l_ticketDate = new JLabel("乘车日",SwingConstants.LEFT);
		t_ticketDate = new JTextField(pb.getTicketDate(),16);
		t_ticketDate.setToolTipText("格式:2013-01-01");
		l_expectedSeatTypes = new JLabel("座位类型",SwingConstants.LEFT);
		t_expectedSeatTypes = new JTextField(pb.getExpectedSeatTypes(),16);
		t_expectedSeatTypes.setToolTipText("硬座,软座,硬卧,软卧,高级软卧,二等座,一等座,特等座,商务座(多个用逗号分割)");
		JPanel p_ticket= new JPanel();
		p_ticket.setLayout(new FlowLayout(FlowLayout.LEFT));
		p_ticket.add(l_ticketDate);
		p_ticket.add(t_ticketDate);
		p_ticket.add(l_expectedSeatTypes);
		p_ticket.add(t_expectedSeatTypes);
		
		JPanel p_details = new JPanel();
		TitledBorder b_details =new TitledBorder("detail information"); 
		p_details.setBorder(b_details);
		p_details.setLayout(new GridLayout(5,1));
		p_details.add(p_user);
		p_details.add(p_idcard);
		p_details.add(p_tel);
		p_details.add(p_train);
		p_details.add(p_ticket);
		
		btn_login = new JButton("登录买票");
		btn_login.addActionListener(new LoginActionListener());
		JPanel p_login = new JPanel();
		p_login.setLayout(new FlowLayout());
		p_login.add(btn_login);

		JPanel p_top = new JPanel();
		p_top.setLayout(new BorderLayout());
		p_top.add(p_website,BorderLayout.NORTH);
		p_top.add(p_details,BorderLayout.CENTER);
		p_top.add(p_login,BorderLayout.SOUTH);
		
		ta_log = new JTextArea(10,10);
		ta_log.setLineWrap(true);
		ta_log.setWrapStyleWord(true);
		p_log = new JScrollPane(ta_log);
		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(p_top,BorderLayout.NORTH);
		panel.add(p_log,BorderLayout.CENTER);
		setContentPane(panel);
	}
	
	public static void main(String[] args) throws Exception {
		frame = new MainFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
		frame.addWindowListener(new WindowAdapter(){
			@Override
			public void windowOpened(WindowEvent e) {
				try{
					//获取cookie
					httpsCookieHeaders = HttpUtil.getHttpsCookie();
					//dolog("获取https cookie："+java.util.Arrays.toString(httpsCookieHeaders));
					//获取验证码
					setLoginRandCode(btn_randcode);
					//设置焦点
					if(pb.getUsername() != null && !pb.getUsername().equals("")){
						t_randcode.grabFocus();
					}
				}catch(Exception ex){
					ex.printStackTrace();
				}
			}
		});
	}
	private static class LoginActionListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			String username = t_username.getText();
			String password = t_password.getText();
			String randcode = t_randcode.getText();
			int loginResult = HttpUtil.login(username,password,randcode,httpsCookieHeaders);
			try{
				if(loginResult != 0){//登录失败
						//清空验证码
						t_randcode.setText("");
						t_randcode.grabFocus();
						//重新生成验证码，再次登录
						setLoginRandCode(btn_randcode);
				}else{//登录成功
					new Thread(new Worker()).start();
				}
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	private static class Worker implements Runnable{
		@Override
		public void run() {
			try{
				String trainCode = t_trainCode.getText();
				String fromStationName = t_fromStationName.getText();
				String toStationName = t_toStationName.getText();
				String	ticketDate = t_ticketDate.getText();
				pb.setTrainCode(trainCode);
				pb.setFromStationName(fromStationName);
				pb.setToStationName(toStationName);
				pb.setTicketDate(ticketDate);
				pb.setExpectedSeatTypes(t_expectedSeatTypes.getText());
				pb.setName(t_user.getText());
				pb.setIdcard(t_idcard.getText());
				pb.setTel(t_tel.getText());
				
				//获取trainNo
				String trainNo = HttpUtil.getTrainNo(trainCode,fromStationName,toStationName,ticketDate,httpsCookieHeaders);
				if(trainNo == null || trainNo.equals("")){
					//重新输入车次信息
					dolog("您输入的车次信息有错误,请重新输入!");
					t_trainCode.setText("");
					t_trainCode.grabFocus();
				}else{
					pb.setTrainNo(trainNo);
					dolog("获取trainNo:"+trainNo);
					//开始订票
					while(true){
						//查票
						String[] ticketinfoArr = HttpUtil.doQueryTicket(pb,httpsCookieHeaders);
						//预定车票
						HttpUtil.doBookTicket(pb,ticketinfoArr,httpsCookieHeaders); 
						//提交订单
						int result = HttpUtil.doSubmitOrder(pb,ticketinfoArr,httpsCookieHeaders);
						if(result == 0){
							break;
						}
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	public static String getOrderRandCode(Header[] httpsCookieHeaders){
		final JDialog randcodeDialog = new JDialog(frame, "输入验证码", true);
		randcodeDialog.setSize(200, 150);
		randcodeDialog.setLocationRelativeTo(frame);

		JLabel l_randcode = new JLabel("请输入验证码:", JLabel.CENTER);
		
		final JTextField t_randcode = new JTextField(10);
		final JButton btn_randcode = new JButton("");
		btn_randcode.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				setOrderRandCode(btn_randcode);
			}
		});
		setOrderRandCode(btn_randcode);
		JPanel p_randcode = new JPanel();
		p_randcode.setLayout(new FlowLayout());
		p_randcode.add(t_randcode);
		p_randcode.add(btn_randcode);

		JButton btn_confirm = new JButton("提交");
		JPanel p_confirm = new JPanel();
		btn_confirm.addActionListener(new ActionListener( ) {
			public void actionPerformed(ActionEvent ev) {
				String randcode = t_randcode.getText();
				if(randcode == null || randcode.trim().length() != 4){
					t_randcode.setText("");
					t_randcode.grabFocus();
				}else{
					pb.setOrderRandcode(randcode);
					dolog("订单验证码："+randcode);
					//System.out.println("订单验证码："+randcode);
					randcodeDialog.setVisible(false);
					randcodeDialog.dispose();
				}
			}
		});
		p_confirm.add(btn_confirm);
		
		Container container = randcodeDialog.getContentPane();
		container.setLayout(new GridLayout(3,1));
		container.add(l_randcode);
		container.add(p_randcode);
		container.add(p_confirm);

		randcodeDialog.setVisible(true);
		return pb.getOrderRandcode();
	}
	private static class GetRandCodeListener implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			try{
				JButton btn = (JButton)e.getSource();
				setLoginRandCode(btn);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
	public static void setLoginRandCode(JButton btn){
		try{
			byte[] imageData = HttpUtil.getLoginRandCode(httpsCookieHeaders);
			setRandCode(btn,imageData);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void setOrderRandCode(JButton btn){
		try{
			byte[] imageData = HttpUtil.getOrderRandCode(httpsCookieHeaders);
			setRandCode(btn,imageData);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void setRandCode(JButton btn,byte[] imageData)throws Exception{
		btn.setText("");
		ImageIcon randcode = new ImageIcon(imageData);
		btn.setMargin(null);
		btn.setBorder(null);
		btn.setIcon(randcode);
	}
	public static void dolog(final String message) {
		try{
			if(ta_log != null){
				ta_log.append(message);
				ta_log.append("\r\n");
				ta_log.setSelectionStart(ta_log.getText().length());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
