package test.buyticket;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpRequestInterceptor;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.RequestLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HttpContext;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class HttpClientUtil {
	
	public static HttpClient getHttpClient()throws Exception{
		DefaultHttpClient httpclient = new DefaultHttpClient();
		httpclient.addRequestInterceptor(new HttpRequestInterceptor() {
			public void process(final HttpRequest request,
					final HttpContext context) throws HttpException,
					IOException {
				if (!request.containsHeader("Accept")) {
					request.addHeader("Accept", "*/*");
				}
				if (request.containsHeader("User-Agent")) {
					request.removeHeaders("User-Agent");
				}
				if (request.containsHeader("Connection")) {
					request.removeHeaders("Connection");
				}
				if (request.containsHeader("Host")) {
					request.removeHeaders("Host");
				}
				request.addHeader("Host", "kyfw.12306.cn");
				request.addHeader("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36");
				request.addHeader("Connection", "keep-alive");
			}
		});
		return httpclient;
	}
	public static HttpClient getHttpsClient()throws Exception{
		DefaultHttpClient httpclient = new DefaultHttpClient();
		TrustManager easyTrustManager = new X509TrustManager() {
		   public void checkClientTrusted(java.security.cert.X509Certificate[]x509Certificates, String s) throws java.security.cert.CertificateException {
		    }
		   public void checkServerTrusted(java.security.cert.X509Certificate[]x509Certificates, String s) throws java.security.cert.CertificateException {
		    }
		   public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		       return null;
		    }
		};
		SSLContext sslcontext =SSLContext.getInstance("TLS");
		sslcontext.init(null, new TrustManager[]{easyTrustManager}, null);
		SSLSocketFactory sf = new SSLSocketFactory(sslcontext);
		Scheme sch = new Scheme("https",443,sf);
		httpclient.getConnectionManager().getSchemeRegistry().register(sch);
	
		httpclient.addRequestInterceptor(new HttpRequestInterceptor() {
			public void process(final HttpRequest request,
					final HttpContext context) throws HttpException,
					IOException {
				if (!request.containsHeader("Accept")) {
					request.addHeader("Accept", "*/*");
				}
				if (request.containsHeader("User-Agent")) {
					request.removeHeaders("User-Agent");
				}
				if (request.containsHeader("Connection")) {
					request.removeHeaders("Connection");
				}
				if (request.containsHeader("Host")) {
					request.removeHeaders("Host");
				}
				request.addHeader("Host", "kyfw.12306.cn");
				request.addHeader("User-Agent","Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36");
				request.addHeader("Connection", "keep-alive");
			}
		});
		return httpclient;
	}
	public static HttpResponse sendPost(String url,Map<String,String> dataMap,Header... headers)throws Exception{
		HttpPost post = new HttpPost(url);
		return sendRequest(post,dataMap,headers);
	}
	public static HttpResponse sendGet(String url,Header...headers)throws Exception{
		HttpGet get = new HttpGet(url);
		System.out.println("execute sendGet method now");
		return sendRequest(get,null,headers);
	}
	public static HttpResponse sendRequest(HttpRequestBase request,Map<String,String> dataMap,Header...headers)throws Exception{
		RequestLine requestLine = request.getRequestLine();
		HttpClient httpclient = null;
		if(requestLine.getUri().toLowerCase().startsWith("https")){
			System.out.println("Request uri:"+requestLine.getUri().toLowerCase());
			httpclient = getHttpsClient();
		}else{
			httpclient = getHttpClient();
		}
		
		if(dataMap != null && dataMap.size() > 0){
			List <NameValuePair> nvps = new ArrayList <NameValuePair>();
			for(Map.Entry<String,String> entry : dataMap.entrySet()){
				String key = entry.getKey();
				String value = entry.getValue();
	            nvps.add(new BasicNameValuePair(key,value ));
			}
			((HttpPost)request).setEntity(new UrlEncodedFormEntity(nvps, Consts.UTF_8));
			request.setHeader("Content-Length",""+((HttpPost)request).getEntity().getContentLength());
			request.setHeader("Content-Type","application/x-www-form-urlencoded");
			
		}else{
			System.out.println("the request data parameter head is empty");
		}
		if(headers != null && headers.length > 0){
			request.setHeaders(headers);
		}
		System.out.println("execute request now...");
		return  httpclient.execute(request);
	}
	public static Header[] getRequestCookieHeader(HttpResponse response){
		Header[] responseHeaders = response.getHeaders("Set-Cookie");
		if(responseHeaders == null || responseHeaders.length <= 0){
			System.out.println("the request set cookies is null");
			return null;
		}
		Header[] requestCookies = new BasicHeader[responseHeaders.length];
		for(int i=0;i<responseHeaders.length;i++){
			requestCookies[i] = new BasicHeader("Cookie",responseHeaders[i].getValue());
		}
		return requestCookies;
	}
	
}
