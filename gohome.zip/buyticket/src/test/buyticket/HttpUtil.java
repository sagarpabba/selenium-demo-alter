package test.buyticket;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.http.Header;
import org.apache.http.HttpResponse;

/**
 * @author xujsh(xjs250@163.com)
 *
 */
public class HttpUtil {
	
	public static Header[] getHttpsCookie()throws Exception{
		String httpsIndexUrl = "https://kyfw.12306.cn/otn/";
		HttpResponse response = HttpClientUtil.sendGet(httpsIndexUrl,(Header[])null);
		Header[] httpsCookieHeaders = HttpClientUtil.getRequestCookieHeader(response);
		
		MainFrame.dolog("获取https cookie:"+java.util.Arrays.toString(httpsCookieHeaders));
		return httpsCookieHeaders;
	}
	
	public static byte[] getLoginRandCode(Header[] httpsCookieHeaders)throws Exception{
		//获取登陆验证码
		String initFormUrl = "https://kyfw.12306.cn/otn/login/init";
		Header referHeader = Utils.makeReferHeader(initFormUrl);
		Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
		String loginPassCodeUrl = "https://kyfw.12306.cn/otn/passcodeNew/getPassCodeNew?module=login&rand=sjrand";
				//https://dynamic.12306.cn/otsweb/passCodeAction.do?rand=sjrand";
		HttpResponse response = HttpClientUtil.sendGet(loginPassCodeUrl,headers);
		InputStream in = response.getEntity().getContent();
		return Utils.readInputStream(in);
	}
	public static int login(String username,String password,String randcode,Header[] httpsCookieHeaders){
		try{
			String initFormUrl = "https://dynamic.12306.cn/otsweb/loginAction.do?method=init";
			//获取登陆的随机数
			Header referHeader = Utils.makeReferHeader(initFormUrl);
			Header headers[] = Utils.buildHeader(referHeader,httpsCookieHeaders);
			String loginRandUrl = "https://dynamic.12306.cn/otsweb/loginAction.do?method=loginAysnSuggest";
			HttpResponse response = HttpClientUtil.sendPost(loginRandUrl,null,headers);
			String content = Utils.getContent(response.getEntity().getContent());
			JSONObject jo = JSONObject.fromObject(content);
			String loginRand = jo.getString("loginRand");
			//System.out.println("登陆随机数是："+loginRand);
			MainFrame.dolog("登陆随机数是："+loginRand);
			//构造登录参数,登陆
			Map<String,String> loginDataMap = new HashMap<String,String>();
			loginDataMap.put("loginRand", loginRand);
			loginDataMap.put("refundLogin", "N");
			loginDataMap.put("refundFlag", "Y");
			loginDataMap.put("loginUser.user_name", username);
			loginDataMap.put("nameErrorFocus", "");
			loginDataMap.put("user.password",password );
			loginDataMap.put("passwordErrorFocus","");
			loginDataMap.put("randCode", randcode);
			loginDataMap.put("randErrorFocus", "");
			//System.out.println("所有的登录参数是："+loginDataMap);
			MainFrame.dolog("所有的登录参数是："+loginDataMap);
			//登陆
			referHeader = Utils.makeReferHeader(initFormUrl);
			headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
			String dologinUrl = "https://dynamic.12306.cn/otsweb/loginAction.do?method=login";
			response = HttpClientUtil.sendPost(dologinUrl,loginDataMap,headers);
			String loginResult = Utils.getContent(response.getEntity().getContent());
			//System.out.println(loginResult);
			if(loginResult.indexOf("欢迎")>-1){
				//System.out.println("登陆成功！");
				MainFrame.dolog("登陆成功！");
				return 0;
			}else{
				//System.out.println(loginResult);
				//System.out.println("登陆失败！");
				MainFrame.dolog(loginResult);
				MainFrame.dolog("登陆失败！");
				return -1;
			}
		}catch(Exception ex){
			ex.printStackTrace();
			return -1;
		}
	}
	public static String getTrainNo(String trainCode,String fromStationName,String toStationName,String ticketDate,Header[] httpsCookieHeaders){
		Map<String,String> data = new HashMap<String,String>();
		data.put("fromstation", StationNameUtil.getStationTelecode(fromStationName));
		data.put("tostation", StationNameUtil.getStationTelecode(toStationName));
		data.put("date", ticketDate);
		data.put("starttime", "00:00--24:00");
		Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=init");
		Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
		for(int idx=0;idx<5;idx++){
			try{
				String queryStationUrl = "https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=queryststrainall";
				//date=2012-09-29&fromstation=BJP&tostation=SHH&starttime=00%3A00--24%3A00
				HttpResponse response = HttpClientUtil.sendPost(queryStationUrl,data,headers);
				String content = Utils.getContent(response.getEntity().getContent());
				//System.out.println(content);
				//{"end_station_name":"上海虹桥","end_time":"12:23","id":"240000G10102","start_station_name":"北京南","start_time":"07:00","value":"G101"},
				JSONArray ja = JSONArray.fromObject(content);
				for(int i=0;i<ja.size();i++){
					JSONObject jo = (JSONObject)ja.get(i);
					String tCode = jo.getString("value");
					if(trainCode.toLowerCase().trim().equals(tCode.toLowerCase().trim())){
						String tNo = jo.getString("id");
						//System.out.println("获取trainNo:"+tNo);
						return tNo;
					}
				}
			}catch(Exception e){}
		}
		//System.out.println("您输入的车次信息有错误！请重新输入");
		return null;
	}
	
	public static String[] doQueryTicket(ParamBean pb,Header[] httpsCookieHeaders)throws Exception{
		//查票
		String startTime = "";
		String endTime = "";
		String mmStr = "";
		String ypInfoDetail = "";
		String usetime = "";
		String queryTicketUrl = "https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=queryLeftTicket&orderRequest.train_date="+pb.getTicketDate()+"&orderRequest.from_station_telecode="+StationNameUtil.getStationTelecode(pb.getFromStationName())+"&orderRequest.to_station_telecode="+StationNameUtil.getStationTelecode(pb.getToStationName())+"&orderRequest.train_no="+pb.getTrainNo()+"&trainPassType=QB&trainClass=QB%23D%23Z%23T%23K%23QT%23&includeStudent=00&seatTypeAndNum=&orderRequest.start_time_str=00%3A00--24%3A00";
		Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=init");
		Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
		int i = 0;
		while(true){
			//System.out.println("第"+(++i)+"次查询");
			MainFrame.dolog("第"+(++i)+"次查询");
			if(i > 0){
				//每隔一秒刷一次
				try{Thread.sleep(1000);}catch(Exception e){e.printStackTrace();}
			}
			HttpResponse response = HttpClientUtil.sendGet(queryTicketUrl,headers);
			String queryResult = Utils.getContent(response.getEntity().getContent());
			//System.out.println(queryResult);
			if(queryResult == null || queryResult.equals("") || queryResult.trim().equals("-1"))continue;
			//queryResult是用\n分隔的字符串
			String queryResults[] = queryResult.split("\n");
			if(queryResults.length <= 0)continue;
			if(queryResults[0].equals("-1")){
				//System.out.println("重新查询！");
				MainFrame.dolog("重新查询！");
				continue;
			}
			boolean find = false;
			for(int idx = 0;idx <queryResults.length;idx++){
				String[] queryResultArr = queryResults[idx].split(",",-1);
				String[] matchResult = Utils.matchTicket(queryResultArr,pb.getExpectedSeatTypes());
				if(matchResult!=null){
					//System.out.println("预定："+matchResult[0]+","+matchResult[2]+",从"+matchResult[7]+"到"+matchResult[8]);
					MainFrame.dolog("预定："+matchResult[0]+","+matchResult[2]+",从"+matchResult[7]+"到"+matchResult[8]);
					pb.setFromStationName(matchResult[7]);//修正用户的输入信息
					pb.setToStationName(matchResult[8]);//修正用户的输入信息
					usetime = matchResult[1];
					startTime = matchResult[2];
					endTime = matchResult[6];
					ypInfoDetail = matchResult[9];
					mmStr = matchResult[10];
					find = true;
					break;
				}
			}
			if(!find){
				//System.out.println("没票了！");
				MainFrame.dolog("没票了！");
				continue;
			}else{
				//找到一个票就退出
				break;
			}
		}
		return new String[]{startTime,endTime,mmStr,ypInfoDetail,usetime};
	}
	public static int doBookTicket(ParamBean pb,String[] ticketinfoArr,Header[] httpsCookieHeaders)throws Exception{
		while(true){
			String beforeOrderTicketUrl = "https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=submutOrderRequest";
			Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=init");
			Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
			Map<String,String> data = new HashMap<String,String>();
			data.put("station_train_code",pb.getTrainCode());
			data.put("from_station_name",pb.getFromStationName());
			data.put("from_station_telecode",StationNameUtil.getStationTelecode(pb.getFromStationName()));
			data.put("from_station_telecode_name",pb.getFromStationName());
			data.put("to_station_name",pb.getToStationName());
			data.put("to_station_telecode",StationNameUtil.getStationTelecode(pb.getToStationName()));
			data.put("to_station_telecode_name",pb.getToStationName());
			data.put("train_start_time",ticketinfoArr[0]);
			data.put("arrive_time",ticketinfoArr[1]);
			data.put("lishi",ticketinfoArr[4]);
			data.put("mmStr",ticketinfoArr[2]);
			data.put("trainno4",pb.getTrainNo());
			data.put("ypInfoDetail",ticketinfoArr[3]);
			data.put("include_student","00");
			data.put("round_start_time_str","00:00--24:00");
			data.put("start_time_str","00:00--24:00");
			data.put("round_train_date",pb.getTicketDate());
			data.put("train_date",pb.getTicketDate());
			data.put("seattype_num","");
			data.put("single_round_type","1");
			data.put("train_class_arr","QB#D#Z#T#K#QT#");
			data.put("train_pass_type","QB");
			//System.out.println("所有的预订数据："+data);
			MainFrame.dolog("所有的预订数据："+data);
			HttpResponse response = HttpClientUtil.sendPost(beforeOrderTicketUrl,data,headers);
			String beforeOrderResult = Utils.getContent(response.getEntity().getContent());
			//System.out.println("预订结果："+beforeOrderResult);
			if(beforeOrderResult.indexOf("系统忙") > -1){
				//System.out.println("预订失败");
				MainFrame.dolog("预订失败");
			}else{
				//System.out.println("预订成功");
				MainFrame.dolog("预订成功");
				break;
			}
			//每隔一秒刷一次
			try{Thread.sleep(1000);}catch(Exception e){e.printStackTrace();}
		}
		return 0;
	}
	public static int doSubmitOrder(ParamBean pb,String[] ticketinfoArr,Header[] httpsCookieHeaders)throws Exception{
		String strutsToken = "";
		String leftTicketToken = "";
		String buySeatNo = "";
		boolean first = true;
		while(true){
			if(!first){
				//每隔一秒刷一次
				try{Thread.sleep(1000);}catch(Exception e){e.printStackTrace();}
			}
			first = false;
			//获取页面token,余票token
			String confirmOrderUrl = "https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=init";
			Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/querySingleAction.do?method=init");
			Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
			HttpResponse response = HttpClientUtil.sendGet(confirmOrderUrl,headers);
			String content = Utils.getContent(response.getEntity().getContent());
			//System.out.println("content:"+content);
			strutsToken = Utils.getStrutsToken(content);
			//System.out.println("获取struts token："+strutsToken);
			MainFrame.dolog("获取struts token："+strutsToken);
			leftTicketToken = Utils.getLeftTicketToken(content);
			//System.out.println("获取余票 token："+leftTicketToken);
			MainFrame.dolog("获取余票 token："+leftTicketToken);
			//得到可购买的座位的类别
			String seatAvailable = Utils.getSeatAvailable(content);
			//System.out.println("可以购买的座位是："+seatAvailable);
			MainFrame.dolog("可以购买的座位是："+seatAvailable);
			List<String> expectedSeatAvailable = Utils.getExpectedSeatAvailable(seatAvailable,pb.getExpectedSeatTypes());
			if(expectedSeatAvailable == null || expectedSeatAvailable.size() <= 0){
				//System.out.println("没有您期望的座位！！");
				MainFrame.dolog("没有您期望的座位！！");
				continue;
			}
			//System.out.println("符合您选择并且可以购买的座位是："+expectedSeatAvailable);
			MainFrame.dolog("符合您选择并且可以购买的座位是："+expectedSeatAvailable);
			int maxTicketCount  = 0;
			String maxTicketSeatTypeNo = "";
			String maxTicketSeatTypeName = "";
			for(int i=0;i<expectedSeatAvailable.size();i++){
				String seatTypeName = expectedSeatAvailable.get(i);
				String seatTypeNo = Utils.getSeatNo(seatTypeName);
				//查询余票数
				String ticketLeft = "https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=getQueueCount&train_date="+pb.getTicketDate()+"&station="+pb.getTrainCode()+"&seat="+seatTypeNo+"&from="+StationNameUtil.getStationTelecode(pb.getFromStationName())+"&to=StationNameUtil.getStationTelecode(pb.getToStationName())&ticket="+leftTicketToken;
				referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=init");
				headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
				response = HttpClientUtil.sendGet(ticketLeft,headers);
				content = Utils.getContent(response.getEntity().getContent());
				//System.out.println("余票的content:"+content);
				JSONObject jo = JSONObject.fromObject(content);
				String ticketLeftCount = jo.getString("ticket");
				//System.out.println("座位类型："+seatTypeName+",余票数:"+ticketLeftCount);
				MainFrame.dolog("座位类型："+seatTypeName+",余票数:"+ticketLeftCount);
				//选一个票数最多的提交，提高概率
				int realTicketCount = Integer.parseInt(ticketLeftCount);
				if(maxTicketCount < realTicketCount){
					maxTicketCount = realTicketCount;
					maxTicketSeatTypeNo = seatTypeNo;
					maxTicketSeatTypeName = seatTypeName;
				}
			}
			if(maxTicketCount <= 0){
				continue;
			}else{
				buySeatNo = maxTicketSeatTypeNo;
				//System.out.println("要购买:"+maxTicketSeatTypeName+",余票数："+maxTicketCount);
				MainFrame.dolog("要购买:"+maxTicketSeatTypeName+",余票数："+maxTicketCount);
				break;
			}
		}
		//获取订单验证码
		String orderRandCode = MainFrame.getOrderRandCode(httpsCookieHeaders);
		//提交订单
		String orderUrl = "https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=confirmSingleForQueueOrder";
		Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=init");
		Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
		Map<String,String> orderData = new HashMap<String,String>();
		orderData.put("org.apache.struts.taglib.html.TOKEN",strutsToken);
		orderData.put("textfield","中文或拼音首字母");
		orderData.put("checkbox0","0");
		orderData.put("leftTicketStr",leftTicketToken);
		orderData.put("orderRequest.train_date",pb.getTicketDate());
		orderData.put("orderRequest.train_no",pb.getTrainNo());
		orderData.put("orderRequest.station_train_code",pb.getTrainCode());
		orderData.put("orderRequest.from_station_telecode",StationNameUtil.getStationTelecode(pb.getFromStationName()));
		orderData.put("orderRequest.to_station_telecode",StationNameUtil.getStationTelecode(pb.getToStationName()));
		orderData.put("orderRequest.seat_type_code","");
		orderData.put("orderRequest.seat_detail_type_code","");
		orderData.put("orderRequest.ticket_type_order_num","");
		orderData.put("orderRequest.bed_level_order_num","000000000000000000000000000000");
		orderData.put("orderRequest.start_time",ticketinfoArr[0]);
		orderData.put("orderRequest.end_time",ticketinfoArr[1]);
		orderData.put("orderRequest.from_station_name",pb.getFromStationName());
		orderData.put("orderRequest.to_station_name",pb.getToStationName());
		orderData.put("orderRequest.cancel_flag","1");
		orderData.put("orderRequest.id_mode","Y");
		orderData.put("randCode",orderRandCode);
		orderData.put("orderRequest.reserve_flag","A");
		orderData.put("passenger_1_seat",buySeatNo);//座位类别
		orderData.put("passenger_1_seat_detail","0");//上下铺，0表示随机
		orderData.put("passenger_1_ticket","1");//票数目？
		orderData.put("passenger_1_name",pb.getName());//姓名
		orderData.put("passenger_1_cardtype","1");//身份证
		orderData.put("passenger_1_cardno",pb.getIdcard());
		orderData.put("passenger_1_mobileno",pb.getTel());//手机号
		orderData.put("passengerTickets",Utils.getPassengerTickets(orderData));
		//System.out.println("所有的订单数据："+orderData);
		MainFrame.dolog("所有的订单数据："+orderData);
		HttpResponse response = HttpClientUtil.sendPost(orderUrl,orderData,headers);
		String orderResult = Utils.getContent(response.getEntity().getContent());
		//System.out.println("提交订单，返回："+orderResult);//{"errMsg":"Y"}
		MainFrame.dolog("提交订单，返回："+orderResult);//{"errMsg":"Y"}
		JSONObject jo = JSONObject.fromObject(orderResult);
		String errmsg = jo.getString("errMsg");
		if(errmsg != null && errmsg.equals("Y")){
			//System.out.println("恭喜你，订票成功！赶紧去支付吧！");
			MainFrame.dolog("恭喜你，订票成功！赶紧去支付吧！");
			return 0;
		}else{
			//System.out.println("订票失败，别着急，再来一次！");
			MainFrame.dolog("订票失败，别着急，再来一次！");
			return -1;
		}
	}
	public static byte[] getOrderRandCode(Header[] httpsCookieHeaders)throws Exception{
		//获取订单验证码
		String orderRandCodeUrl = "https://dynamic.12306.cn/otsweb/passCodeAction.do?rand=randp";
		Header referHeader = Utils.makeReferHeader("https://dynamic.12306.cn/otsweb/order/confirmPassengerAction.do?method=init");
		Header[] headers = Utils.buildHeader(referHeader,httpsCookieHeaders);
		HttpResponse response = HttpClientUtil.sendGet(orderRandCodeUrl,headers);
		InputStream in = response.getEntity().getContent();
		return Utils.readInputStream(in);
	}
}
